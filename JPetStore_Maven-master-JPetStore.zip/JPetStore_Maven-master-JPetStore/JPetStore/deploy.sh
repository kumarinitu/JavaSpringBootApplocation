docker run -it --rm -p 8128:8080 tomcat:8.0                                                        
